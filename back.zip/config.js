const systemConfig = {
    defaultStringValue: "default"
}

module.exports = systemConfig